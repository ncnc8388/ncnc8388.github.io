/*
@header({
  searchable: 2,
  filterable: 0,
  quickSearch: 1,
  title: '量子资源[资]',
  '类型': '影视',
  lang: 'ds'
})
*/

// https://cj.lziapi.com/api.php/provide/vod/?ac=list

var rule = {
    模板: '采集1',
    title: '量子资源[资]',
    host: 'https://cj.lziapi.com',
    // homeTid: '13',
    homeTid: '',
    cate_exclude: '电影片|连续剧|综艺片|动漫片|电影解说|体育|演员|新闻资讯',
    parse_url: '',
}